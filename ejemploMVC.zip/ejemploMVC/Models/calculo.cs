﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class calculo
    {
        public int numero1 { get; set; }
        public int numero2 { get; set; }

        public double num { get; set; }

        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
    }
}